<?php
include "dbcon.php";

if(isset($_POST['add']))
{
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $dob = $_POST['dob'];
    $mstatus = $_POST['mstatus'];
    $gender = $_POST['gender'];
    $email = $_POST['email'];
    $con = $_POST['con'];
    $acon = $_POST['acon'];
    $add1 = $_POST['add1'];
    $add2 = $_POST['add2'];
    $postcode = $_POST['postcode'];
    $qualification = $_POST['qualification'];
    $branch = $_POST['branch'];
    $myfile1 = $_FILES['myfile1'];
    $course = $_POST['course'];
    
    $insert = mysqli_query($db,"INSERT INTO `staff_form`(`fname`, `lname`,`dob`, `mstatus`, `gender`, `email`,`con`,`acon`,`add1`,`add2`,`postcode`,`qualification`,
    `branch`,`resume`,`course`) 
    VALUES('$fname', '$lname', '$dob', '$mstatus', '$gender', '$email', '$con','$acon','$add1','$add2','$postcode','$qualification','$branch','$myfile1','$course')");
    
   if($insert)
    {
        {
	echo '<script type = "text/javascript">';
    echo 'alert("Form Submitted Successfully!");';
    echo 'window.location.href = "index.php"';
    echo '</script>';
	}
    }
    else
    {
        echo "please enter required fields";
    }
}
?>
<?php
if( isset($_POST['add']))
{
    $my1=$_FILES['myfile1']['name'];
   
    $temp_name1 = $_FILES['myfile1']['tmp_name'];
   
    $path_filename_ext="upload/";
   
    move_uploaded_file($temp_name1, 'upload/'.$my1);

}
?>
   