<?php 
session_start();

	include("dbcon.php");
	include("functions.php");

	if($_SERVER['REQUEST_METHOD'] == "POST")
	{
		//something was posted
		$user_name = $_POST['user_name'];
		$password = $_POST['password'];
		$email=$_POST['email'];
        
		if((!empty($user_name)) && (!empty($email)) && (!empty($password)) && (!is_numeric($user_name))){

			//save to database
			$user_id = random_num(20);
			$query = "insert into users (user_id,user_name,email,password) values ('$user_id','$user_name','$email','$password')";

			mysqli_query($db, $query);

			header("Location: login.php");
			die;
		} else {
			echo "Please enter some valid information!";
		}
	}
?>


<!DOCTYPE html>
<html>
<head>
	<title>Signup</title>
</head>
<body>

	<style type="text/css">
	
	#text{
		display: block;
		width: 100%;
		padding: 0.75rem;
		box-sizing: border-box;
		border-radius:5px;
		border: 1px solid #0c0c0c;
		outline: none;
		background: #eeeeee;
		transition: background 0.2s, border-color 0.2s;
		font: 500 1rem 'Quicksand', sans-serif;

		/*height: 25px;
		border-radius: 5px;
		padding: 4px;
		border: solid thin #aaa;
		width: 100%;*/
	}

	#button{
		width: 100%;
		padding: 1rem 2rem;
		font-weight: bold;
		font-size: 1.1rem;
		border: none;
		border-radius: 5px;
		outline: none;
		cursor: pointer;
		background: crimson;
		color: white;

		/*padding: 10px;
		width: 100px;
		color: white;
		background-color: lightblue;
		border: none;*/
	}
	.form__text {
    text-align: center;
	}

	.form__link {
		color: var(--color-secondary);
		text-decoration: none;
		cursor: pointer;
	}

	.form__link:hover {
		text-decoration: underline;
	}

	#box{
		width: 400px;
		max-width: 400px;
		margin: 1rem;
		padding: 2rem;
		box-shadow: 0 0 40px rgba(0, 0, 0, 0.2);
		border-radius: var(--border-radius);
		background: #ffffff;
		font: 500 1rem 'Quicksand', sans-serif;
		/*background-color: grey;
		margin: auto;
		width: 300px;
		padding: 20px;*/
	}
	body{
		padding-top:3%;
		justify-content:center;
		padding-left:35%;
	}


	</style>

	<div id="box">
		
		<form method="post">
			<div style="font-size: 20px;margin: 10px;color: black;  margin-bottom: 2rem;
    text-align: center;"><h1>Create Account</h1></div>
			
			<input id="text" type="text" name="user_name" autofocus placeholder="Username"><br><br>
			<input id="text" type="email" name="email" autofocus placeholder="Email Address"><br><br>
			<input id="text" type="password" name="password" autofocus placeholder="Password"><br><br>
			<input id="text" type="password" autofocus placeholder="Confirm password"><br><br>
			<input id="button" type="submit" value="Continue"><br><br>
			<p class="form__text">
                <a class="form__link" href="login.php">Already have an account? Sign in</a>
            </p>

			
		</form>
	</div>
</body>
</html>