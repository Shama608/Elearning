<?php
session_start();
error_reporting(0);
?>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Website</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/typed.js/2.0.11/typed.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/waypoints/4.0.1/jquery.waypoints.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" />
    <style>
        .navbar {
            position: fixed;
            width: 100%;
            z-index: 999;
            padding: 10px 0;
            font-family: 'Ubuntu', sans-serif;
            transition: all 0.3s ease;
            background: crimson;
        }
        
        .navbar .logo a {
            color: white;
            font-size: 35px;
            font-weight: 600;
        }
        
        .navbar .logo a span {
            color: white;
            transition: all 0.3s ease;
        }
        
        .navbar.sticky .logo a span {
            color: #fff;
        }
    </style>
</head>

<body>
    <div class="scroll-up-btn">
        <i class="fas fa-angle-up"></i>
    </div>
    <nav class="navbar">
        <div class="max-width">
            <div class="logo"><a href="index.html">Spa<span>rk.</span></a></div>
            <div class="menu-btn">
                <i class="fas fa-bars"></i>
            </div>
        </div>
    </nav>
    <section class="about" id="about">
        <div class="max-width">
            <h2 class="title">PHP</h2>
            <div class="about-content">
                <div class="column left">
                    <img src="images/php.png" alt="">
                </div>
                <div class="column right">
                    <!--<div class="text"><span class="typing-2"></span></div>-->
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quasi ut voluptatum eveniet doloremque autem excepturi eaque, sit laboriosam voluptatem nisi delectus. Facere explicabo hic minus accusamus alias fuga nihil dolorum quae. Explicabo
                        illo unde, odio consequatur ipsam possimus veritatis, placeat, ab molestiae velit inventore exercitationem consequuntur blanditiis omnis beatae. Dolor iste excepturi ratione soluta quas culpa voluptatum repudiandae harum non.</p>
      
  <a href="application2.php" class="menu-btn" id="login">Apply Now</a>
  <a href="index.php" class="menu-btn" id="login">Back to Home</a>

                </div>
            </div>
        </div>
    </section>
	<footer>
        <span>Created By <a href="index.php">Birds Work</a> | <span class="far fa-copyright"></span> 2022 All rights reserved.</span>
    </footer>

    <script src="script.js"></script>
</body>

</html>