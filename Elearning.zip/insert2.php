<?php
include "dbcon.php";

if(isset($_POST['add']))
{
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $faname = $_POST['faname'];
    $dob = $_POST['dob'];
    $gender = $_POST['gender'];
    $email = $_POST['email'];
    $con = $_POST['con'];
    $acon = $_POST['acon'];
    $add1 = $_POST['add1'];
    $add2 = $_POST['add2'];
    $postcode = $_POST['postcode'];
    $course = $_POST['course'];
    $month = $_POST['month'];
    
    $insert = mysqli_query($db,"INSERT INTO `student_form`(`fname`, `lname`, `faname`, `dob`,`gender`, `email`,`con`,`acon`,`add1`,`add2`,`postcode`,`course`,`month`) 
    VALUES('$fname', '$lname', '$faname','$dob', '$gender', '$email', '$con','$acon','$add1','$add2','$postcode','$course','$month')");
    
   if($insert)
    {
        {
	echo '<script type = "text/javascript">';
    echo 'alert("Form Submitted Successfully!");';
    echo 'window.location.href = "index.php"';
    echo '</script>';
	}
    }
    else
    {
        echo "please enter required fields";
    }
}
?>
   