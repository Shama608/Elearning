<?php 
include "dbcon.php";
include('includes/header.php'); 
include('includes/navbar.php'); 
?>


        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                 <h1 class="h3 mb-2 text-gray-800" style="margin-left: 415px;font-weight: bold;">Staff Report</h1>
             
                <div class="container-fluid">

                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <!--h6 class="m-0 font-weight-bold text-primary">DataTables Example</h6-->
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0" >
                                         <tr>
                        <th>TD</th>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Date Of Birth</th>
                        <th>Marital Status</th>
                        <th>Gender</th>
                        <th>Email</th>
                        <th>Phone Number</th>
                        <th>Alternative Number</th>
                        <th>Current Address</th>
                        <th>Permanent Address</th>
                        <th>Postal Code</th>
                        <th>Qualification</th>
                        <th>Branch</th>
                        <th>Resume</th>
                        <th>Course</th>
                        <th colspan="2">Action</th>
                        
            </tr>
            
            <?php
            error_reporting(0);
            $selectquery = "select * from staff_form where status='pending' order by id asc" ;
            $query = mysqli_query($db,$selectquery);
            $total = mysqli_num_rows($query);
             
            echo $result['id']." ".$result['fname']." ".$result['lname']." ".$result['dob']." ".$result['mstatus']."" .$result['gender']." ".$result['email']." " .$result['con']
            ." ".$result['acon']." ".$result['add1']." ".$result['add2']." ".$result['postcode']." ".$result['qualification']." ".$result['branch']." ".$result['resume']." ".$result['course'];
            //echo "$total";
            
            if($total!=0)
            {
                
                while(($result = mysqli_fetch_array($query)))
                {
                ?>
                    <tr>
                    <td><?php echo $result['id'] ?></td>
                    <td><?php echo $result['fname'] ?></td>
                    <td><?php echo $result['lname'] ?></td>
                    <td><?php echo $result['dob'] ?></td>
					<td><?php echo $result['mstatus'] ?></td>
                    <td><?php echo $result['gender'] ?></td>
                    <td><?php echo $result['email'] ?></td>
                    <td><?php echo $result['con'] ?></td>
                    <td><?php echo $result['acon'] ?></td>
                    <td><?php echo $result['add1'] ?></td>
                    <td><?php echo $result['add2'] ?></td>
                    <td><?php echo $result['postcode'] ?></td>
                    <td><?php echo $result['qualification'] ?></td>
                    <td><?php echo $result['branch'] ?></td>
                    <td><?php echo $result['resume'] ?></td>
                    <td><?php echo $result['course'] ?></td>
                     
		<td>
        <form action="staffreport.php" method="POST">
        <input type="hidden" name="id" value="<?php echo $result['id']?>">
        <input type="submit" class="btn-success" name="approve" value="Approve"/> 
        </form></td>
        <td>
        <form action="staffreport.php" method="POST">
        <input type="hidden" name="id" value="<?php echo $result['id']?>">
        <input class="btn-danger" type="submit" name="reject" value="Reject"/> 
        </form></td>
    </tr>
                
                   
                 
                
                <?php
                   
            
                }
                
            }
            else{
                echo "table has no records";
            }
			
            ?>
            </table>
            </body>
            <?php
				 if(isset($_POST['approve'])){
				 $id = $_POST['id'];
				$select1 = "UPDATE staff_form SET status='approve' where id ='$id'";
				$res = mysqli_query($db, $select1);
				
				echo '<script type = "text/javascript">';
				echo 'alert("User Approved Successfully!");';
				echo 'window.location.href = "staffapprovalreport.php"';
				echo '</script>';
				 }
				
			?>         
            <?php
           
            if(isset($_POST['reject'])){
                $id = $_POST['id'];
            
               $select = "DELETE FROM staff_form WHERE id = '$id'";
               $result = mysqli_query($db, $select);
            
                echo '<script type = "text/javascript">';
                echo 'alert("User Denied successfully!");';
               echo 'window.location.href = "staffreport.php"';
                echo '</script>';
            }
            ?>
                                   
                                    
                                    <tbody>
                                  
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            
        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
   

    <!-- Bootstrap core JavaScript-->
   <?php
include('includes/scripts.php');
include('includes/footer.php');
?>


</body>

</html>