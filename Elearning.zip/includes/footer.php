

      <!-- Footer -->
     <footer style="
  text-align: center;
  padding-top: 27px;
  background-color: white;
  font-size: 1rem;
    font-weight: 400;
    line-height: 1.5;
    color: #858796;">
  <p>Copyright &copy; Your Website 2020</p>
</footer>

      <!-- End of Footer -->
      </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->
    </div>
    <!-- End of Content Wrapper -->

    
</body>

</html>
