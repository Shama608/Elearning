<?php 

session_start();

	include("dbcon.php");
	include("functions.php");


	if($_SERVER['REQUEST_METHOD'] == "POST")
	{
		//something was posted
		$user_name = $_POST['user_name'];
		$password = $_POST['password'];
	

		if(!empty($user_name) && !empty($password) && !is_numeric($user_name))
		{

			//read from database
			$query = "select * from users where user_name = '$user_name' limit 1";
			$result = mysqli_query($db, $query);

			if($result)
			{
				if($result && mysqli_num_rows($result) > 0)
				{

					$user_data = mysqli_fetch_assoc($result);
					
					if($user_data['password'] === $password)
					{

						$_SESSION['user_id'] = $user_data['user_id'];
						header("Location: admin.php");
						die;
					}
				}
			}
			
			echo"<script>alert('wrong username or password!')</script>";
		}else
		{
			echo"<script>alert('Please Enter Required Field!')</script>";
		}
	}

?>



<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">
	<title>Login</title>
	<link rel="shortcut icon" href="/assets/favicon.ico">
</head>
<body>

	<style type="text/css">
	
	body{
		padding-top:6%;
		justify-content:center;
	}


	#text{
		display: block;
		width: 100%;
		padding: 0.75rem;
		box-sizing: border-box;
		border-radius:5px;
		border: 1px solid #0c0c0c;
		outline: none;
		background: #eeeeee;
		transition: background 0.2s, border-color 0.2s;
		font: 500 1rem 'Quicksand', sans-serif;
	}

	#button{
		 width: 100%;
		padding: 1rem 2rem;
		font-weight: bold;
		font-size: 1.1rem;
		border: none;
		border-radius: 5px;
		outline: none;
		cursor: pointer;
		background: #5a73ef;
		color: white;
	}

	#button : hover{
		background-color:#870720;
	}

	#box{

		width: 400px;
		max-width: 400px;
		margin: auto;
		padding: 2rem;
		box-shadow: 0 0 40px rgba(0, 0, 0, 0.2);
		border-radius: var(--border-radius);
		background: #ffffff;
		font: 500 1rem 'Quicksand', sans-serif;
	}
	.form__text {
    text-align: center;
	}

	.form__link {
		color: var(--color-secondary);
		text-decoration: none;
		cursor: pointer;
	}

	.form__link:hover {
		text-decoration: underline;
	}

	</style>

	<div id="box">
		
		<form method="post">
			<div style="font-size: 20px;margin: 10px;color: black;  margin-bottom: 2rem;
    text-align: center;"><h1>Login</h1></div>
			<div>
			<input  id="text" type="text" name="user_name" autofocus placeholder="Username " ><br><br>
			<input id="text" type="password" name="password" autofocus placeholder="Password"><br><br>
			</div>
			<input id="button" type="submit" href="admin.php" value="Continue"><br><br>
			<p class="form__text">
                <!--a href="#" class="form__link">Forgot your password?</a-->
            </p>
            <p class="form__text">
                <a class="form__link" href="signup.php">Don't have an account? Create account</a>
            </p>
			<!--a href="signup.php">Click to Signup</a><br><br-->
		</form>
	</div>
</body>
</html>