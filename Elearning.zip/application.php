<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Application Form</title>
	<!-- CSS only -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
   
</head>

<body>

   
        
       <div class="container">
  <center><h2 style="margin-top: 20px;
    margin-bottom: 25px;
    background-color: crimson;
    color: white;
    padding: 5px;
    font-weight: bold;border-radius: 5px;">Staff Application form</h2></center>
  <form name="form" method="post" action="insert1.php" class="wrapper" enctype="multipart/form-data" >
    <div class="form-group">
	<div class="row">
	<div class="col-sm-6">
      <label>First Name:</label>
      <input type="text" class="form-control "  placeholder="Enter First Name" name="fname" required>
    </div>
	<div class="col-sm-6">
      <label>Last Name:</label>
      <input type="text" class="form-control "  placeholder="Enter Last Name" name="lname" required>
    </div>
	</div>
	<div class="row">
	<div class="col-sm-6">
      <label>Date of Birth:</label>
      <input type="date" class="form-control "  placeholder="" name="dob" required>
    </div>
	<div class="col-sm-6">
      <label>Marital Status:</label>
     
            <select class="form-control" name="mstatus" required>
            <option value="Select">Select</option>
            <option value="single">Single</option>  
            <option value="married">Married</option>  
            <option value="other">Other</option>  
            </select>
                
    </div>
	</div>
	<div class="row">
	<div class="col-sm-6">
      <label>Gender:</label>
      <select class="form-control" name="gender" required>
              <option value="">Select</option>
              <option value="male">Male</option>
              <option value="female">Female</option>
            </select>
               
    </div>
	<div class="col-sm-6">
      <label>E-mail:</label>
      <input type="email" class="form-control"  placeholder="" name="email" required>
    </div>
	
	</div>
	<div class="row">
	<div class="col-sm-6">
      <label>Phone Number:</label>
      <input type="text" class="form-control " id="text1" placeholder="Enter Phone Number" name="con" required pattern="[0-9]+">
    </div>
	<div class="col-sm-6">
      <label>Alternate Number:</label>
      <input type="text" class="form-control "  id="text2" placeholder="Enter Alternate Number" name="acon" required pattern="[0-9]+">
    </div>
	</div>
	<div class="row">
	<div class="col-sm-6">
      <label>Current Address:</label>
      <input type="text" class="form-control "  placeholder="Enter your Current Address" name="add1" required>
    </div>
	<div class="col-sm-6">
      <label>Permanent Address:</label>
      <input type="text" class="form-control "  placeholder="Enter your Permanent Address" name="add2">
    </div>
	</div>
	<div class="row">
	<div class="col-sm-6">
      <label>Postal Code:</label>
      <input type="text" class="form-control " id="text3" placeholder="Enter Pincode" name="postcode" required pattern="[0-9]+">
    </div>
	<div class="col-sm-6">
	<label>Qualification:</label>
                <select class="form-control" name="qualification" required>
            <option value="Select">Select</option>       
            <option value="Engineering">Engineering</option>  
            <option value="Degree">Degree</option>  
            <option value="Diploma">Diploma</option>  
            <option value="IIT">IIT</option>   
            </select>
 </div>
  </div>
 <div class="row">
 <div class="col-sm-6">
  <label> Branch:</label>
   <input type="text" class="form-control "  placeholder="Enter Branch" name="branch" required>
 </div>
 <div class="col-sm-6">
  <label> Upload Resume:</label>
   <input type="file" id="myfile" class="form-control "  placeholder="" name="myfile1" required>
 </div>
  
	  </div>
 <div class="row">
 <div class="col-sm-6">
                <label>Course : </label>
                    <select class="form-control" name="course" required>  
            <option value="Course">Course</option>  
            <option value="HTML">HTML</option>  
            <option value="CSS">CSS</option>  
            <option value="JavaScript">JavaScript</option>  
            <option value="PHP">PHP</option>  
            <option value="C#">C#</option>  
            <option value="C++">C++</option>  
            </select>
 </div>
  <div class="col-sm-3">
<input type="submit" style="margin-top: 24px;background-color: #03c1f9;color: white;
    font-weight: bold;
    font-size: 16px;" value="Submit" class="form-control" name="add">
            </div>
			 <div class="col-sm-3">
<input type="submit" style="margin-top: 24px;background-color: #03c1f9;color: white;
    font-weight: bold;
    font-size: 16px;" value="Back" onclick="location.href='index.php'" class="form-control" name="back">
</div>
 
	  </div>
       
   </form>
<script>
$(function () {
        $("#text1").keypress(function (e)
 		{
            var keyCode = e.keyCode || e.which;
            $("#lblError1").html("");
            var regex = /^[0-9]+$/;
            var isValid = regex.test(String.fromCharCode(keyCode));
            if (!isValid) {
                $("#lblError1").html("Only  Numbers allowed.");
            }
            return isValid;
        });
    });
	$(function () {
        $("#text2").keypress(function (e)
 		{
            var keyCode = e.keyCode || e.which;
            $("#lblError1").html("");
            var regex = /^[0-9]+$/;
            var isValid = regex.test(String.fromCharCode(keyCode));
            if (!isValid) {
                $("#lblError1").html("Only  Numbers allowed.");
            }
            return isValid;
        });
    });
	$(function () {
        $("#text3").keypress(function (e)
 		{
            var keyCode = e.keyCode || e.which;
            $("#lblError1").html("");
            var regex = /^[0-9]+$/;
            var isValid = regex.test(String.fromCharCode(keyCode));
            if (!isValid) {
                $("#lblError1").html("Only  Numbers allowed.");
            }
            return isValid;
        });
    });
</script>
</body>

</html>