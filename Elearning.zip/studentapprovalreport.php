<?php 
include "dbcon.php";
include('includes/header.php'); 
include('includes/navbar.php'); 
?>

        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                 <h1 class="h3 mb-2 text-gray-800" style="margin-left: 415px;font-weight: bold;">Student Approved Report</h1>
               
                <div class="container-fluid">

                   

                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <!--h6 class="m-0 font-weight-bold text-primary">DataTables Example</h6-->
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                 
                                        <tr>
            <th>SI NO</th>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Father Name</th>
            <th>Date Of Birth</th>
            <th>Gender</th>
            <th>Email</th>
            <th>Phone Number</th>
            <th>Alternative Number</th>
            <th>Current Address</th>
            <th>Permanent Address</th>
            <th>Postal Code</th>
            <th>Course</th>
			<th>Batch</th>
            <th>Month</th>
			<th>Delete</th>
            <!--th colspan="2">Action</th-->
            
</tr>
                                        
                                        <?php
error_reporting(0);

$selectquery = "select * from student_form where status='approve'";
$query = mysqli_query($db,$selectquery);
$total = mysqli_num_rows($query);
 
echo $result['id']." ".$result['fname']." ".$result['lname']." ".$result['faname']." ".$result['dob']." " .$result['gender']." ".$result['email']." " .$result['con']
." ".$result['acon']." ".$result['add1']." ".$result['add2']." ".$result['postcode']." ".$result['course']." ".$result['batch']." ".$result['month'];
//echo "$total";

if($total!=0)
{
    
    while(($result = mysqli_fetch_array($query)))
    {?>
        
        <tr>
        <td><?php echo $result['id'] ?></td>
        <td> <?php echo $result['fname']?></td>
        <td><?php echo $result['lname']?></td>
        <td><?php echo $result['faname']?></td>
        <td><?php echo $result['dob']?></td>
        <td><?php echo $result['gender']?></td>
        <td><?php echo $result['email']?></td>
        <td><?php echo $result['con'] ?></td>
        <td><?php echo $result['acon']?></td>
        <td> <?php echo $result['add1']?></td>
        <td><?php echo $result['add2']?></td>
        <td><?php echo $result['postcode']?></td>
        <td><?php echo $result['course']?></td>
		<td><?php echo $result['batch']?></td>
        <td><?php echo $result['month']?></td> 
        <td>
        <form action="studentapprovalreport.php" method="POST">
        <input type="hidden" name="id" value="<?php echo $result['id']?>">
        <button class="btn-danger" type = 'submit' name ='reject'><i class="fas fa-trash-alt"></i> </button>
        </form>
        </form>
            
        </tr>
            <?php
    
        }
        
    }else{
        echo "table has no records";
    }
    ?>
                     
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
           
        </div>
        <!-- End of Content Wrapper -->

    </div>
   
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

   <?php
include('includes/scripts.php');
include('includes/footer.php');
?>


</body>
<?php

if(isset($_POST['reject'])){
    $id = $_POST['id'];

   $select = "DELETE FROM student_form WHERE id = '$id'";
    $result = mysqli_query($db, $select);

    echo '<script type = "text/javascript">';
    echo 'alert("User Deleted Successfully!");';
   echo 'window.location.href = "studentapprovalreport.php"';
    echo '</script>';
}
?>
</html>