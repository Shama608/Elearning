<?php
session_start();
error_reporting(0);
if(!isset($_SESSION['user_id'])){
   header("location:login.php");
     die();
}
include("dbcon.php");
include("functions.php");
include('includes/header.php'); 
include('includes/navbar.php'); 

?>



<div class="container-fluid">

  <div class="row">

   
    <div class="col-xl-3 col-md-6 mb-4">
      <div class="card border-left-primary shadow h-100 py-2">
        <div class="card-body">
          <div class="row no-gutters align-items-center">
            <div class="col mr-2">
              <div style="color:red;font-size:16px;font-weight:bold">Student Application Pending</div>
              <div class="h5 mb-0 font-weight-bold text-gray-800">

               <h4><?php error_reporting(0);
            $selectquery = "select * from student_form where status='pending' order by id asc" ;
            $query = mysqli_query($db,$selectquery);
            $total = mysqli_num_rows($query);
			echo $total ;?></h4>

              </div>
			  
            </div>
           <div class="col-auto">
              <i class="fas fa-comments fa-2x text-gray-300"></i>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Earnings (Monthly) Card Example -->
    <div class="col-xl-3 col-md-6 mb-4">
      <div class="card border-left-primary shadow h-100 py-2">
        <div class="card-body">
          <div class="row no-gutters align-items-center">
            <div class="col mr-2">
              <div style="color:#19b919;font-size:16px;font-weight:bold">Number of Student Approved</div>
              <div class="h5 mb-0 font-weight-bold text-gray-800">

               <h4><?php error_reporting(0);
            $selectquery = "select * from student_form where status='approve' order by id asc" ;
            $query = mysqli_query($db,$selectquery);
            $total = mysqli_num_rows($query);
			echo $total ;?></h4>

              </div>
            </div>
            <div class="col-auto">
          <i class="fa fa-check fa-2x text-gray-300"></i>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Earnings (Monthly) Card Example -->
    <div class="col-xl-3 col-md-6 mb-4">
      <div class="card border-left-primary shadow h-100 py-2">
        <div class="card-body">
          <div class="row no-gutters align-items-center">
            <div class="col mr-2">
              <div style="color:blue;font-size:16px;font-weight:bold">Staff Application Pending</div>
              <div class="h5 mb-0 font-weight-bold text-gray-800">

               <h4><?php error_reporting(0);
            $selectquery = "select * from staff_form where status='pending' order by id asc" ;
            $query = mysqli_query($db,$selectquery);
            $total = mysqli_num_rows($query);
			echo $total ;?></h4>

              </div>
            </div>
            <div class="col-auto">
              <i class="fas fa-comments fa-2x text-gray-300"></i>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Pending Requests Card Example -->
    <div class="col-xl-3 col-md-6 mb-4">
      <div class="card border-left-primary shadow h-100 py-2">
        <div class="card-body">
          <div class="row no-gutters align-items-center">
            <div class="col mr-2">
              <div style="color:#c9c93b;font-size:16px;font-weight:bold">Number of Staff Approved</div>
              <div class="h5 mb-0 font-weight-bold text-green-800">

               <h4><?php error_reporting(0);
            $selectquery = "select * from staff_form where status='approve' order by id asc" ;
            $query = mysqli_query($db,$selectquery);
            $total = mysqli_num_rows($query);
			echo $total ;?></h4>

              </div>
            </div>
            <div class="col-auto">
              <i class="fa fa-check fa-2x text-gray-300"></i>
            </div>
          </div>
        </div>
      </div>
    </div>
	</div>
    </div>

  <!-- Content Row -->
 <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>


<footer style="margin-top:300px;" class="sticky-footer bg-white">
        <div class="container my-auto">
          <div style="font-size:16px;" class="copyright text-center my-auto">
            <span>Copyright &copy; Your Website 2019</span>
          </div>
        </div>
      </footer>





  <?php
include('includes/scripts.php');

?>