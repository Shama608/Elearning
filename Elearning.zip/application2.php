<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Application Form</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    
    
</head>

<body>
     <div class="container">
  <center><h2 style="margin-top: 20px;
    margin-bottom: 25px;
    background-color: crimson;
    color: white;
    padding: 5px;
    font-weight: bold;border-radius: 5px;">Student Application form</h2></center>
    <form  action="insert2.php" method="POST" class="wrapper">
    <div class="form-group">
	<div class="row">
	<div class="col-sm-6">
                <label>First Name:</label>
                <input type="text" class="form-control" name="fname" required>
            </div>
           <div class="col-sm-6">
                <label>Last Name:</label>
                <input type="text" class="form-control" name="lname" required>
            </div>           
			</div>
			<div class="row">
            <div class="col-sm-6">
                <label>Father Name:</label>
                <input type="text" class="form-control" name="faname" required>
            </div>
           <div class="col-sm-6">
                <label> Date of Birth: </label>
                <input type="date" name="dob" class="form-control" required/>
            </div>
			</div>
            <div class="row">
            <div class="col-sm-6">
                <label>Gender:</label>
                    <select class="form-control" name="gender" required>
              <option value="choose">Select</option>
              <option value="male">Male</option>
              <option value="female">Female</option>
            </select>
             </div>
            <div class="col-sm-6">
                <label>Email Address:</label>
                <input type="text" class="form-control" name="email" required>
            </div>
			 </div>
            <div class="row">
            <div class="col-sm-6">
                <label>Phone Number:</label>
                <input type="text" id="text1" class="form-control" name="con" required pattern="[0-9]+">
            </div>
             <div class="col-sm-6">
                <label>Alternative Number:</label>
                <input type="text" id="text2" class="form-control" name="acon">
            </div>
			</div>
            <div class="row">
            <div class="col-sm-6">
                <label>Current Address:</label>
                <textarea class="form-control" name="add1"></textarea>
            </div>
             <div class="col-sm-6">
                <label>Permanent Address:</label>
                <textarea class="form-control" name="add2" required></textarea>
            </div>
			</div>
             <div class="row">
            <div class="col-sm-6">
                <label>Postal Code:</label>
                <input type="text" id="text3" class="form-control" name="postcode" required pattern="[0-9]+">
            </div>

             <div class="col-sm-6">
                <label>Course:</label>
                    <select class="form-control" name="course">  
            <option value="Course">Course</option>  
            <option value="HTML">HTML</option>  
            <option value="CSS">CSS</option>  
            <option value="JavaScript">JavaScript</option>  
            <option value="PHP">PHP</option>  
            <option value="C#">C#</option>  
            <option value="C++">C++</option>  
            </select>
                </div>
            </div></br>
             <div class="row">
            <div class="col-sm-6">
                <label>Select Month:</label>&nbsp;&nbsp;&nbsp;
                <input  type="radio" id="month" name="month" value="1month" required>
                <label for="1month">1 Month</label>&nbsp;&nbsp;&nbsp;
                <input type="radio" id="month" name="month" value="3month" required>
                <label for="3month">3 Month</label>&nbsp;&nbsp;&nbsp;
                <input type="radio" id="month" name="month" value="6month" required>
                <label for="6month">6 Month</label>
            </div>
            
           
  <div class="col-sm-3">
<input type="submit" style="background-color: #03c1f9;color: white;
    font-weight: bold;
    font-size: 16px;" value="Submit" class="form-control" name="add">
            </div>
			 <div class="col-sm-3">
<input type="submit" style="background-color: #03c1f9;color: white;
    font-weight: bold;
    font-size: 16px;" value="Back" onclick="location.href='index.php'" class="form-control" name="back">
</div>
 
	  </div>
    </form>
<script>
$(function () {
        $("#text1").keypress(function (e)
 		{
            var keyCode = e.keyCode || e.which;
            $("#lblError1").html("");
            var regex = /^[0-9]+$/;
            var isValid = regex.test(String.fromCharCode(keyCode));
            if (!isValid) {
                $("#lblError1").html("Only  Numbers allowed.");
            }
            return isValid;
        });
    });
	$(function () {
        $("#text2").keypress(function (e)
 		{
            var keyCode = e.keyCode || e.which;
            $("#lblError1").html("");
            var regex = /^[0-9]+$/;
            var isValid = regex.test(String.fromCharCode(keyCode));
            if (!isValid) {
                $("#lblError1").html("Only  Numbers allowed.");
            }
            return isValid;
        });
    });
	$(function () {
        $("#text3").keypress(function (e)
 		{
            var keyCode = e.keyCode || e.which;
            $("#lblError1").html("");
            var regex = /^[0-9]+$/;
            var isValid = regex.test(String.fromCharCode(keyCode));
            if (!isValid) {
                $("#lblError1").html("Only  Numbers allowed.");
            }
            return isValid;
        });
    });
</script>
</body>

</html>